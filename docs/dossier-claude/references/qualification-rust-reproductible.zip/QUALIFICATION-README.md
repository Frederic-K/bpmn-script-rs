# Rejouer la qualification

Prérequis : Windows, outils de liaison MSVC, rustup accessible et un Python contenant openpyxl 3.1.5. Le premier lancement peut télécharger Rust et les dépendances Cargo. Les versions Cargo restent celles du verrou fourni.

Depuis ce dossier :

```powershell
.\run-qualification.ps1 -Python 'C:\chemin\vers\python.exe'
```

Le script installe Rust 1.88.0 dans `.toolchains` sans changer le Rust par défaut global. Il compile les sources originales, exécute 30 scénarios synthétiques et vérifie les résultats attendus. Les différences connues sont caractérisées, pas approuvées comme contrat final. Lire `qualification-rust.md` pour leurs conséquences.

Les tests écrivent dans `qualification-runs/`. Une nouvelle exécution conserve les anciennes preuves dans des dossiers numérotés. Les deux JSON de synthèse sont remplacés par les résultats du dernier lancement.

Pour ajouter le test réel en trois étapes, copier le SGX fourni sous le nom `SAPHIR - Modélisation des processus cibles.sgx` à la racine de ce dossier. Le pilote ne modifie que des copies et génère des décisions expérimentales. Ses SGX de sortie ne représentent pas un arbitrage métier approuvé.

Les sources incluses viennent des trois archives fournies. Le fichier `rust-toolchain.toml` fixe uniquement l’outil de compilation. Aucun code métier n’a été corrigé dans cette passe. Les résultats conservés dans ce paquet proviennent des essais du 26 septembre 2026, y compris SAPHIR.

Le pilote dépend volontairement des fixtures de l’archive hybride. Il compare les résultats des exécutables ; ce n’est pas une suite de tests unitaires Rust. Les styles Excel sont relevés séparément et les différences ZIP ne sont pas assimilées à des différences de contenu métier.
