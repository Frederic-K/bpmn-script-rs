from pathlib import Path
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
import zipfile
import json


fichiers_sgx = list(
    Path("input").glob("*.sgx")
)

if len(fichiers_sgx) == 0:
    raise FileNotFoundError(
        "Aucun fichier SGX trouvé dans input/"
    )

if len(fichiers_sgx) > 1:
    raise RuntimeError(
        "Plusieurs fichiers SGX trouvés dans input/ : "
        "un seul fichier est attendu"
    )

sgx = fichiers_sgx[0]

print(
    f"[OK] Fichier SGX sélectionné : {sgx.name}"
)

fichier_correspondance = Path("work/correspondance_swimlanes.xlsx")


def trouver_lanes(shape):
    lanes = []

    if shape.get("stencil", {}).get("id") == "Lane":
        nom = shape.get("properties", {}).get("name", "").strip()

        if nom:
            lanes.append(nom)

    for enfant in shape.get("childShapes", []):
        lanes.extend(trouver_lanes(enfant))

    return lanes

def renommer_lanes(shape, nom_actuel, nouveau_nom):
    nombre_modifications = 0

    if shape.get("stencil", {}).get("id") == "Lane":
        nom = shape.get("properties", {}).get("name", "")

        if isinstance(nom, str) and nom.strip() == nom_actuel:
            shape["properties"]["name"] = nouveau_nom
            nombre_modifications += 1

    for enfant in shape.get("childShapes", []):
        nombre_modifications += renommer_lanes(
            enfant,
            nom_actuel,
            nouveau_nom
        )

    return nombre_modifications

resultats = []

# Extraction des lanes depuis le SGX
with zipfile.ZipFile(sgx) as archive:
    print("[OK] Archive SGX ouverte")

    fichiers_modeles = [
        chemin for chemin in archive.namelist()
        if chemin.endswith("model_1_.json")
    ]

    for fichier_modele in fichiers_modeles:
        fichier_meta = fichier_modele.replace(
            "model_1_.json",
            "model_meta.json"
        )

        contenu_meta = archive.read(fichier_meta).decode("utf-8")
        meta = json.loads(contenu_meta)

        nom_flux = meta.get("name", "")
 
        contenu_modele = archive.read(fichier_modele).decode("utf-8")
        modele = json.loads(contenu_modele)

        lanes = trouver_lanes(modele)

        for lane in lanes:
            resultats.append({
                "fichier_modele": fichier_modele,
                "flux": nom_flux,
                "lane": lane
            })

print(f"[OK] Extraction terminée : {len(resultats)} occurrences")


# Sauvegarde de l'extraction brute
with open("output/resultats.json", "w", encoding="utf-8") as fichier:
    json.dump(
        resultats,
        fichier,
        ensure_ascii=False,
        indent=2
    )


print("[OK] resultats.json généré")


# Construction de la synthèse
synthese = {}

for resultat in resultats:
    lane = resultat["lane"]
    flux = resultat["flux"]
    fichier_modele = resultat["fichier_modele"]

    if lane not in synthese:
        synthese[lane] = {
            "occurrences": 0,
            "flux": [],
            "occurrences_par_flux": {},
            "occurrences_par_modele": {}
        }

    synthese[lane]["occurrences"] += 1

    if flux not in synthese[lane]["flux"]:
        synthese[lane]["flux"].append(flux)

    if flux not in synthese[lane]["occurrences_par_flux"]:
        synthese[lane]["occurrences_par_flux"][flux] = 0

    synthese[lane]["occurrences_par_flux"][flux] += 1

    if fichier_modele not in synthese[lane]["occurrences_par_modele"]:
        synthese[lane]["occurrences_par_modele"][fichier_modele] = {
            "flux": flux,
            "occurrences": 0
        }

    synthese[lane]["occurrences_par_modele"][
        fichier_modele
    ]["occurrences"] += 1

print(f"[OK] Synthèse terminée : {len(synthese)} lanes uniques")


# Sauvegarde de la synthèse
with open("output/synthese.json", "w", encoding="utf-8") as fichier:
    json.dump(
        synthese,
        fichier,
        ensure_ascii=False,
        indent=2
    )


print("[OK] synthese.json généré")


# Création du fichier Excel d'inventaire
classeur = Workbook()

feuille = classeur.active
feuille.title = "Correspondance"

feuille.append([
    "Nom actuel",
    "Nouveau nom",
    "Occurrences",
    "Nombre de flux",
    "Flux concernés",
    "Flux avec occurrences multiples"
])


for lane, infos in sorted(synthese.items()):
    multiples = [
        f"{flux} ({nombre})"
        for flux, nombre in infos["occurrences_par_flux"].items()
        if nombre > 1
    ]

    feuille.append([
        lane,
        "",
        infos["occurrences"],
        len(infos["flux"]),
        ", ".join(infos["flux"]),
        ", ".join(multiples)
    ])


# Mise en forme minimale pour faciliter le travail dans Excel
for cellule in feuille[1]:
    cellule.font = Font(bold=True)

feuille.freeze_panes = "A2"
feuille.auto_filter.ref = feuille.dimensions

feuille.column_dimensions["A"].width = 35
feuille.column_dimensions["B"].width = 35
feuille.column_dimensions["C"].width = 15
feuille.column_dimensions["D"].width = 18
feuille.column_dimensions["E"].width = 90
feuille.column_dimensions["F"].width = 90

for ligne in feuille.iter_rows(min_row=2):
    ligne[4].alignment = Alignment(
        wrap_text=True,
        vertical="top"
    )

    ligne[5].alignment = Alignment(
        wrap_text=True,
        vertical="top"
    )

remplissage_saisie = PatternFill(
    fill_type="solid",
    fgColor="FFF2CC"
)

for cellule in feuille["B"][1:]:
    cellule.fill = remplissage_saisie


classeur.save("output/inventaire_swimlanes.xlsx")

print("[OK] Excel généré : output/inventaire_swimlanes.xlsx")


# Vérification de la présence du fichier de correspondance
if not fichier_correspondance.exists():
    print(
        "[INFO] Aucun fichier de correspondance trouvé : "
        "la préparation des modifications est ignorée"
    )

else:
    classeur_lu = load_workbook(fichier_correspondance)

    feuille_lue = classeur_lu["Correspondance"]

    correspondances = {}

    for ligne in feuille_lue.iter_rows(min_row=2, values_only=True):
        nom_actuel = ligne[0]
        nouveau_nom = ligne[1]

        if isinstance(nouveau_nom, str):
            nouveau_nom = nouveau_nom.strip()

        if nouveau_nom:
            correspondances[nom_actuel] = nouveau_nom


    print(
        f"[OK] Correspondances chargées : "
        f"{len(correspondances)}"
    )


    with open(
        "output/correspondances.json",
        "w",
        encoding="utf-8"
    ) as fichier:
        json.dump(
            correspondances,
            fichier,
            ensure_ascii=False,
            indent=2
        )


    print("[OK] correspondances.json généré")


    analyse_modifications = []

    for nom_actuel, nouveau_nom in correspondances.items():
        if nom_actuel in synthese:
            infos = synthese[nom_actuel]

            for fichier_modele, infos_modele in infos[
                "occurrences_par_modele"
            ].items():
                analyse_modifications.append({
                    "fichier_modele": fichier_modele,
                    "flux": infos_modele["flux"],
                    "nom_actuel": nom_actuel,
                    "nouveau_nom": nouveau_nom,
                    "occurrences": infos_modele["occurrences"]
                })


    print(
        f"[OK] Dry-run préparé : "
        f"{len(analyse_modifications)} impacts flux/lane"
    )


    with open(
        "output/analyse_modifications.json",
        "w",
        encoding="utf-8"
    ) as fichier:
        json.dump(
            analyse_modifications,
            fichier,
            ensure_ascii=False,
            indent=2
        )


    print("[OK] analyse_modifications.json généré")


    # Création de l'Excel d'analyse des modifications
    classeur_analyse = Workbook()

    feuille_analyse = classeur_analyse.active
    feuille_analyse.title = "Analyse"

    feuille_analyse.append([
        "Flux",
        "Nom actuel",
        "Nouveau nom",
        "Occurrences",
        "Validation",
        "Fichier modèle"
    ])


    for modification in analyse_modifications:
        feuille_analyse.append([
            modification["flux"],
            modification["nom_actuel"],
            modification["nouveau_nom"],
            modification["occurrences"],
            "",
            modification["fichier_modele"]
        ])


    for cellule in feuille_analyse[1]:
        cellule.font = Font(bold=True)

    feuille_analyse.freeze_panes = "A2"
    feuille_analyse.auto_filter.ref = feuille_analyse.dimensions

    feuille_analyse.column_dimensions["A"].width = 70
    feuille_analyse.column_dimensions["B"].width = 35
    feuille_analyse.column_dimensions["C"].width = 35
    feuille_analyse.column_dimensions["D"].width = 15
    feuille_analyse.column_dimensions["E"].width = 15
    feuille_analyse.column_dimensions["F"].width = 250

    for ligne in feuille_analyse.iter_rows(min_row=2):
        ligne[0].alignment = Alignment(
            wrap_text=True,
            vertical="top"
        )

        ligne[5].alignment = Alignment(
            wrap_text=True,
            vertical="top"
        )

    for cellule in feuille_analyse["E"][1:]:
        cellule.fill = remplissage_saisie


    validation_oui_non = DataValidation(
        type="list",
        formula1='"OUI,NON"',
        allow_blank=True
    )

    feuille_analyse.add_data_validation(
        validation_oui_non
    )

    validation_oui_non.add(
        f"E2:E{feuille_analyse.max_row}"
    )


    classeur_analyse.save(
        "output/analyse_modifications.xlsx"
    )


    print(
        "[OK] Excel d'analyse généré : "
        "output/analyse_modifications.xlsx"
    )

    fichier_validation = Path(
        "work/validation_modifications.xlsx"
    )

    if not fichier_validation.exists():
        print(
            "[INFO] Aucun fichier de validation trouvé : "
            "aucune modification autorisée"
        )

    else:
        classeur_validation = load_workbook(
            fichier_validation
        )

        feuille_validation = classeur_validation["Analyse"]

        modifications_validees = []
        modifications_ignorees = []
        controle_validation = []

        propositions_attendues = {
            (
                modification["fichier_modele"],
                modification["flux"],
                modification["nom_actuel"],
                modification["nouveau_nom"],
                modification["occurrences"],
            )
            for modification in analyse_modifications
        }

        attendus_par_ligne = {
            (
                modification["fichier_modele"],
                modification["flux"],
                modification["nom_actuel"],
                modification["occurrences"]
            ): modification["nouveau_nom"]
            for modification in analyse_modifications
        }

        for numero_ligne, ligne in enumerate(
            feuille_validation.iter_rows(
                min_row=2,
                values_only=True
            ),
            start=2
        ):
            flux = ligne[0]
            nom_actuel = ligne[1]
            nouveau_nom = ligne[2]
            occurrences = ligne[3]
            validation = ligne[4]
            fichier_modele = ligne[5]

            cle_attendue = (
                fichier_modele,
                flux,
                nom_actuel,
                occurrences
            )

            nouveau_nom_attendu = attendus_par_ligne.get(
                cle_attendue
            )

            if isinstance(validation, str):
                validation = validation.strip().upper()

            if validation == "OUI":
                proposition = (
                    fichier_modele,
                    flux,
                    nom_actuel,
                    nouveau_nom,
                    occurrences
                )

                if proposition in propositions_attendues:
                    modifications_validees.append({
                        "fichier_modele": fichier_modele,
                        "flux": flux,
                        "nom_actuel": nom_actuel,
                        "nouveau_nom": nouveau_nom,
                        "occurrences": occurrences
                    })

                    resultat = "VALIDÉE"
                    motif = "Conforme au dry-run"

                else:
                    modifications_ignorees.append({
                        "fichier_modele": fichier_modele,
                        "flux": flux,
                        "nom_actuel": nom_actuel,
                        "nouveau_nom": nouveau_nom,
                        "occurrences": occurrences,
                        "motif": "Ne correspond plus au dry-run"
                    })

                    resultat = "IGNORÉE"
                    motif = "Ne correspond plus au dry-run"

                    print(
                        "[ATTENTION] Une ligne validée ne correspond "
                        "plus au dry-run : modification ignorée"
                    )

            elif validation == "NON":
                resultat = "NON VALIDÉE"
                motif = "Refus humain"

            else:
                resultat = "EN ATTENTE"
                motif = "Aucune validation renseignée"

            controle_validation.append({
                "ligne_validation": numero_ligne,
                "flux": flux,                
                "nom_actuel": nom_actuel,
                "nouveau_nom_saisi": nouveau_nom,
                "nouveau_nom_attendu": nouveau_nom_attendu,
                "occurrences": occurrences,
                "validation": validation,
                "resultat": resultat,
                "motif": motif,
                "fichier_modele": fichier_modele,
            })


        print(
            f"[OK] Modifications validées : "
            f"{len(modifications_validees)}"
        )

        with open(
            "output/modifications_validees.json",
            "w",
            encoding="utf-8"
        ) as fichier:
            json.dump(
                modifications_validees,
                fichier,
                ensure_ascii=False,
                indent=2
            )

        print("[OK] modifications_validees.json généré")

        with open(
            "output/modifications_ignorees.json",
            "w",
            encoding="utf-8"
        ) as fichier:
            json.dump(
                modifications_ignorees,
                fichier,
                ensure_ascii=False,
                indent=2
            )

        print("[OK] modifications_ignorees.json généré")

        classeur_controle = Workbook()

        feuille_controle = classeur_controle.active
        feuille_controle.title = "Contrôle"

        feuille_controle.append([
            "Ligne validation",
            "Flux",
            "Nom actuel",
            "Nouveau nom saisi",
            "Nouveau nom attendu",
            "Occurrences",
            "Validation",
            "Résultat",
            "Motif",
            "Fichier modèle"
        ])

        for controle in controle_validation:
            feuille_controle.append([
                controle["ligne_validation"],
                controle["flux"],
                controle["nom_actuel"],
                controle["nouveau_nom_saisi"],
                controle["nouveau_nom_attendu"],
                controle["occurrences"],
                controle["validation"],
                controle["resultat"],
                controle["motif"],
                controle["fichier_modele"]
            ])

        for cellule in feuille_controle[1]:
            cellule.font = Font(bold=True)

        feuille_controle.freeze_panes = "A2"
        feuille_controle.auto_filter.ref = feuille_controle.dimensions

        feuille_controle.column_dimensions["A"].width = 18
        feuille_controle.column_dimensions["B"].width = 70
        feuille_controle.column_dimensions["C"].width = 35
        feuille_controle.column_dimensions["D"].width = 35
        feuille_controle.column_dimensions["E"].width = 35
        feuille_controle.column_dimensions["F"].width = 15
        feuille_controle.column_dimensions["G"].width = 15
        feuille_controle.column_dimensions["H"].width = 18
        feuille_controle.column_dimensions["I"].width = 40
        feuille_controle.column_dimensions["J"].width = 250

        for ligne in feuille_controle.iter_rows(min_row=2):
            ligne[1].alignment = Alignment(
                wrap_text=True,
                vertical="top"
            )

            ligne[8].alignment = Alignment(
                wrap_text=True,
                vertical="top"
            )

            ligne[9].alignment = Alignment(
                wrap_text=True,
                vertical="top"
            )

        classeur_controle.save(
            "output/controle_validation.xlsx"
        )

        print(
            "[OK] Rapport de contrôle généré : "
            "output/controle_validation.xlsx"
        )

        # Préparation des modèles modifiés en mémoire
        modeles_modifies = {}
        modifications_conformes = True

        with zipfile.ZipFile(sgx) as archive:
            for modification in modifications_validees:
                fichier_modele = modification["fichier_modele"]

                if fichier_modele not in modeles_modifies:
                    contenu_modele = archive.read(
                        fichier_modele
                    ).decode("utf-8")

                    modeles_modifies[fichier_modele] = json.loads(
                        contenu_modele
                    )

                modele = modeles_modifies[fichier_modele]

                nombre_modifications = renommer_lanes(
                    modele,
                    modification["nom_actuel"],
                    modification["nouveau_nom"]
                )

                occurrences_attendues = modification["occurrences"]

                if nombre_modifications == occurrences_attendues:
                    print(
                        "[OK] Test en mémoire conforme : "
                        f"{nombre_modifications} modification(s)"
                    )
                else:
                    modifications_conformes = False

                    print(
                        "[ATTENTION] Test en mémoire non conforme : "
                        f"{nombre_modifications} trouvée(s), "
                        f"{occurrences_attendues} attendue(s)"
                    )

        if modifications_conformes and modifications_validees:
            fichier_sgx_modifie = (
                Path("output")
                / f"{sgx.stem}_modifie.sgx"
            )

            with zipfile.ZipFile(sgx, "r") as archive_source:
                with zipfile.ZipFile(
                    fichier_sgx_modifie,
                    "w"
                ) as archive_sortie:

                    for info in archive_source.infolist():
                        contenu = archive_source.read(
                            info.filename
                        )

                        if info.filename in modeles_modifies:
                            contenu = json.dumps(
                                modeles_modifies[info.filename],
                                ensure_ascii=False
                            ).encode("utf-8")

                        archive_sortie.writestr(
                            info,
                            contenu
                        )

            print(
                "[OK] SGX modifié généré : "
                f"{fichier_sgx_modifie}"
            )