# bpmn-script — outil SGX Signavio

Outil Python local pour inventorier les swimlanes d'un export SAP Signavio `.sgx`, préparer des renommages, les faire valider humainement et générer une nouvelle archive SGX.

Ce mode opératoire décrit le fonctionnement de la V0.1. Le point de retour stable, testé jusqu'à l'import Signavio, est identifié par le tag **`v0.1-sgx-import-tested`**. Conserver ce tag inchangé ; une évolution ultérieure du code doit être testée séparément.

## Installation classique sous Windows

Prérequis : Python installé et accessible avec `py`, les fichiers du projet (`main.py` et `requirements.txt`) et un tableur capable de modifier des fichiers `.xlsx`.

Ouvrir PowerShell **à la racine du dossier `bpmn-script`**, là où se trouve `main.py`, puis exécuter :

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
```

Les dépendances documentées pour cette version sont :

```text
et_xmlfile==2.0.0
openpyxl==3.1.5
```

Le fichier `requirements.txt` de la version utilisée reste la référence pour l'installation. L'appel direct au Python de `.venv` ne nécessite pas d'activer l'environnement dans PowerShell.

Créer les dossiers `input`, `output` et `work` s'ils sont absents. À chaque étape du traitement, lancer depuis la racine du projet :

```powershell
.\.venv\Scripts\python.exe .\main.py
```

Pour utiliser le package Python portable Windows, suivre [README_PORTABLE.md](README_PORTABLE.md).

## Rôle des dossiers

```text
bpmn-script/
├── main.py
├── requirements.txt
├── README.md
├── README_PORTABLE.md
├── input/                 # Export Signavio source
├── output/                # Résultats générés automatiquement
└── work/                  # Correspondances et validations humaines
```

| Dossier | Contenu | Règle |
| --- | --- | --- |
| `input/` | Exactement un fichier `.sgx` source | Aucun Excel dans ce dossier. |
| `output/` | Inventaire, analyse, rapports et SGX modifié | Les fichiers peuvent être régénérés ou écrasés lors d'une relance. |
| `work/` | Les deux fichiers Excel préparés par l'opérateur | Conserver les noms exacts indiqués ci-dessous. |

**Les Excel ne retournent jamais dans `input/`.** Copier les résultats utiles de `output/` vers `work/`, puis modifier uniquement ces copies. Enregistrer et fermer les fichiers Excel avant chaque lancement.

## Workflow pas à pas

```text
Export SGX
  → inventaire
  → correspondance humaine
  → dry-run (analyse des modifications proposées)
  → validation humaine
  → contrôles et génération du SGX modifié
  → vérification dans Signavio
```

La V0.1 détecte automatiquement les fichiers présents dans `work/`. Chaque lancement peut donc poursuivre le traitement jusqu'à l'étape permise par ces fichiers.

### 1. Préparer le traitement

1. Archiver les éléments du cycle précédent à conserver, dans un dossier distinct des trois dossiers de traitement.
2. Retirer l'ancien SGX de `input/` et déposer le nouvel export, par exemple `export_signavio.sgx`.
3. Vider `work/` de ses anciennes correspondances et validations.
4. Vider `output/` après archivage pour éviter de confondre un ancien résultat avec celui du nouveau traitement.

Il doit rester **exactement un fichier `.sgx` dans `input/`**. Le programme s'arrête s'il n'en trouve aucun ou s'il en trouve plusieurs.

### 2. Générer l'inventaire

Lancer le script :

```powershell
.\.venv\Scripts\python.exe .\main.py
```

Récupérer `output/inventaire_swimlanes.xlsx`.

### 3. Préparer les correspondances

**Copier et renommer** le fichier selon cette correspondance :

| Fichier généré à copier | Copie de travail à créer |
| --- | --- |
| `output/inventaire_swimlanes.xlsx` | `work/correspondance_swimlanes.xlsx` |

Dans la copie de travail :

- Renseigner uniquement la colonne **`Nouveau nom`** pour les renommages souhaités.
- Laisser cette colonne vide lorsqu'aucune modification n'est demandée.
- Conserver les autres colonnes et les identifiants sans les modifier.
- Enregistrer au format `.xlsx`, puis fermer le fichier.

### 4. Générer le dry-run

Relancer le script avec la même commande.

Ouvrir `output/analyse_modifications.xlsx` pour examiner les impacts proposés sur les modèles et les swimlanes. À ce stade, en l'absence du fichier de validation, les propositions ne sont pas appliquées dans un nouveau SGX.

### 5. Valider les modifications

**Copier et renommer** :

| Fichier généré à copier | Copie de travail à créer |
| --- | --- |
| `output/analyse_modifications.xlsx` | `work/validation_modifications.xlsx` |

Dans la copie de travail, remplir la colonne **`Validation`** avec **`OUI`** ou **`NON`** pour chaque proposition. Utiliser ces valeurs exactes ; ne pas laisser une décision implicite.

Ne pas modifier les autres informations du dry-run. Enregistrer et fermer le fichier.

Si le SGX source ou les correspondances changent après cette étape, retirer l'ancienne validation de `work/`, régénérer le dry-run et refaire la validation à partir de la nouvelle analyse.

### 6. Générer le SGX modifié

Relancer le script avec la même commande.

Le programme contrôle la cohérence de la validation avec les propositions. Si les contrôles sont conformes et des modifications sont applicables, le résultat attendu est :

```text
input/export_signavio.sgx
  → output/export_signavio_modifie.sgx
```

Le SGX source n'est pas écrasé. Ne pas considérer la seule présence d'un SGX dans `output/` comme une preuve de réussite : vérifier le message de fin du lancement et la date du fichier.

### 7. Contrôler le résultat dans Signavio

1. Consulter `output/controle_validation.xlsx` et vérifier les modifications retenues et ignorées.
2. Vérifier que le nombre de modifications correspond aux décisions prises.
3. Importer le SGX généré dans un dossier Signavio de test autorisé.
4. Contrôler des modèles modifiés et des éléments qui devaient rester inchangés.
5. Utiliser ensuite le résultat selon le circuit de validation de l'organisation.

## Principaux fichiers générés

Selon l'étape atteinte, `output/` contient notamment :

```text
resultats.json
synthese.json
inventaire_swimlanes.xlsx
correspondances.json
analyse_modifications.json
analyse_modifications.xlsx
modifications_validees.json
modifications_ignorees.json
controle_validation.xlsx
<nom_export>_modifie.sgx
```

Les fichiers JSON et les rapports servent à examiner et tracer le traitement ; les décisions humaines sont saisies dans les deux Excel de `work/`.

## Démarrer un nouveau cycle

**Remplacer le SGX ne suffit pas : les anciens fichiers de `work/` peuvent être réutilisés automatiquement.**

Après archivage des éléments à conserver :

1. Retirer l'ancien SGX de `input/` et y déposer le nouveau, seul.
2. Retirer `work/correspondance_swimlanes.xlsx`.
3. Retirer `work/validation_modifications.xlsx`.
4. Nettoyer `output/` pour ne conserver aucun ancien résultat actif.
5. Reprendre depuis la génération de l'inventaire.

Ne pas supprimer les dossiers eux-mêmes. Conserver ensemble, dans l'archive du cycle, le SGX source, les décisions, les rapports et le SGX produit si une traçabilité est nécessaire.

## En cas de problème

| Symptôme | Action |
| --- | --- |
| Aucun SGX ou plusieurs SGX détectés | Vérifier qu'un seul `.sgx` se trouve dans `input/`. |
| Fichier Excel inaccessible | Fermer le fichier dans le tableur, puis relancer. |
| Validation incohérente ou obsolète | Retirer l'ancienne validation, régénérer l'analyse et refaire la validation. |
| Module Python manquant | Réinstaller les dépendances avec le Python de `.venv` et `requirements.txt`. |
| Aucun nouveau SGX produit | Lire les messages et le rapport de contrôle ; vérifier les décisions et ne pas réutiliser un ancien résultat. |

## Documentation et version stable

Conserver `README.md` et `README_PORTABLE.md` à la racine du dépôt pour les versionner. Cette documentation peut être ajoutée à `main` et à `refactor-v1` sans déplacer le tag `v0.1-sgx-import-tested`.

Le dossier `portable/` étant exclu du suivi Git dans la configuration documentée, sa copie de documentation doit être mise à jour lors de la préparation du package. Le code officiel reste `main.py` à la racine du dépôt.
