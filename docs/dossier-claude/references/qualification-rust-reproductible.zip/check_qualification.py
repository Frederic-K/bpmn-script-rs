"""Assertions describing the observed baseline, not acceptance of its defects."""
import json
from pathlib import Path
from openpyxl import load_workbook
root = Path(__file__).resolve().parent
results = json.loads((root / 'rust-qualification-results.json').read_text('utf-8'))
expected_differences = {'empty_mapping', 'unknown_mapping', 'missing_output', 'numeric_old',
                        'numeric_new', 'formula_new', 'null_name', 'bad_children'}
produces = {'accepted', 'mixed', 'normalized_yes', 'partial', 'numeric_new',
            'null_name', 'bad_children', 'zip_attributes', 'same_name'}
for r in results:
    name = r['scenario']
    if name == 'saphir':
        assert r['mapping_names'] == 12 and r['proposals'] == 13
        assert all(not s['differences'] for s in r['stages'])
        assert r['stages'][-1]['runs']['rust']['sgx_after']
        continue
    assert (bool(r['semantic_differences']) or not r['codes_equal']) == (name in expected_differences), name
    assert r['python']['source_intact'] and r['rust']['source_intact']
    if name == 'old_output':
        assert r['rust']['sgx_before'] == r['rust']['sgx_after']
    else:
        assert bool(r['rust']['sgx_after']) == (name in produces), name
    if name == 'zip_attributes':
        check = r['rust']['archive_check']
        assert check['untouched_contents_preserved']
        assert not check['archive_comment_preserved']
        assert {'extra', 'comment'} <= set(check['attribute_changes'][0]['changed_attributes'])
print('Baseline assertions passed: 30 synthetic scenarios + SAPHIR in 3 stages.')
details = {}
for app in ['python', 'rust']:
    details[app] = {}
    for path in (root / 'qualification-runs/accepted' / app / 'output').glob('*.xlsx'):
        book = load_workbook(path)
        s = book.active
        details[app][path.name] = {
            'widths': {c: d.width for c, d in s.column_dimensions.items()},
            'validation': [(str(v.sqref), v.formula1, v.allow_blank) for v in s.data_validations.dataValidation],
            'B2_fill': {'foreground': str(s['B2'].fill.fgColor), 'background': str(s['B2'].fill.bgColor)},
            'E2_fill': {'foreground': str(s['E2'].fill.fgColor), 'background': str(s['E2'].fill.bgColor)},
        }
        book.close()
(root / 'excel-presentation-details.json').write_text(json.dumps(details, indent=2), encoding='utf-8')
print(json.dumps(details, indent=2))
