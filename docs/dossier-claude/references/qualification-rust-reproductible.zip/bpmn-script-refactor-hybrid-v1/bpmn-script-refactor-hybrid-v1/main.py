"""Lancement : python main.py, depuis le dossier de traitement habituel."""

from pathlib import Path
import sys


if __name__ == "__main__":
    # Le Python embarqué Windows peut exclure le dossier du script via son ._pth.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from bpmn_script.workflow import executer

    executer()
