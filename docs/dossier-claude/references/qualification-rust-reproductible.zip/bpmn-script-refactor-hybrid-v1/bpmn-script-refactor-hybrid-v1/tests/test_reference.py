"""Comparaison avec le tag stable sur des données synthétiques, 100 % locale.

Lancer : python tests/test_reference.py (Git et le tag doivent être disponibles).
"""

import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

from openpyxl import Workbook

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from bpmn_script.lanes import trouver_lanes, renommer_lanes
from bpmn_script.regles import construire_synthese

TAG = "v0.1-sgx-import-tested"
MODEL_A = "dossier/a/model_1_.json"
MODEL_B = "dossier/b/model_1_.json"


def lane(name, children=None):
    return {
        "stencil": {"id": "Lane"},
        "properties": {"name": name},
        "childShapes": children or [],
    }


def create_sgx(path):
    models = {
        MODEL_A: {"childShapes": [lane(" A ", [lane("A")]), lane("B"), lane("")]},
        MODEL_B: {"childShapes": [lane("A")]},
    }
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, model in models.items():
            archive.writestr(name, json.dumps(model, ensure_ascii=False))
            archive.writestr(
                name.replace("model_1_.json", "model_meta.json"),
                json.dumps({"name": "Même flux éà"}, ensure_ascii=False),
            )
        archive.writestr("piece_jointe.bin", b"\x00\xffconserver\r\n")
        archive.writestr("dossier/c/model_2_.json", b'{"untouched":true}')


def workbook(path, title, rows):
    book = Workbook()
    sheet = book.active
    sheet.title = title
    for row in rows:
        sheet.append(row)
    book.save(path)
    book.close()


def prepare(folder, scenario):
    for name in ("input", "output", "work"):
        (folder / name).mkdir(parents=True)
    source = folder / "input/export.sgx"
    if scenario == "no_source":
        return
    create_sgx(source)
    if scenario == "multiple_sources":
        shutil.copyfile(source, folder / "input/second.sgx")
    if scenario == "invalid_zip":
        source.write_bytes(b"invalid")
    if scenario == "missing_output":
        (folder / "output").rmdir()
    if scenario in ("inventory", "no_source", "multiple_sources", "invalid_zip", "missing_output"):
        return
    mappings = [["Nom actuel", "Nouveau nom"], ["A", " C é "]]
    if scenario == "empty_mapping":
        mappings = [mappings[0], ["A", "  "]]
    if scenario == "unknown_mapping":
        mappings[1][0] = "inconnue"
    if scenario == "chain_conflict":
        mappings = [mappings[0], ["A", "B"], ["B", "C"]]
    if scenario == "duplicate_mapping":
        mappings.append(["A", "C é"])
    workbook(folder / "work/correspondance_swimlanes.xlsx", "Correspondance", mappings)
    if scenario in ("dry_run", "empty_mapping", "unknown_mapping", "duplicate_mapping"):
        return
    rows = [
        ["Flux", "Nom actuel", "Nouveau nom", "Occurrences", "Validation", "Fichier modèle"],
        ["Même flux éà", "A", "C é", 2, "OUI", MODEL_A],
        ["Même flux éà", "A", "C é", 1, "OUI", MODEL_B],
    ]
    if scenario == "mixed":
        rows[2][4] = "NON"
    if scenario == "refused":
        rows[1][4] = rows[2][4] = "NON"
    if scenario == "pending":
        rows[1][4], rows[2][4] = None, "peut-être"
    if scenario == "normalized_yes":
        rows[1][4] = rows[2][4] = " oui "
    tampered = {"stale_name": (2, "obsolète"), "stale_count": (3, 999),
                "stale_path": (5, "autre/model_1_.json"), "stale_flux": (0, "Autre flux")}
    if scenario in tampered:
        column, value = tampered[scenario]
        rows[1][column] = value
        rows[2][4] = "NON"
    if scenario == "duplicate_validation":
        rows.append(list(rows[1]))
    if scenario == "chain_conflict":
        rows[1][2] = rows[2][2] = "B"
        rows.append(["Même flux éà", "B", "C", 1, "OUI", MODEL_A])
    workbook(folder / "work/validation_modifications.xlsx", "Analyse", rows)


def outputs(folder):
    result = {}
    for file in sorted((folder / "output").glob("*")):
        if file.suffix == ".xlsx":
            # Comparer tout le XML : cellules, styles, filtres, dimensions,
            # validations, feuilles. Seules les dates de création sont variables.
            with zipfile.ZipFile(file) as archive:
                parts = {}
                for name in archive.namelist():
                    data = archive.read(name)
                    if name == "docProps/core.xml":
                        data = re.sub(
                            rb"(<dcterms:(?:created|modified)[^>]*>)[^<]*",
                            rb"\1TIMESTAMP", data,
                        )
                    parts[name] = data
                result[file.name] = parts
        else:
            # JSON et SGX : égalité octet par octet.
            result[file.name] = file.read_bytes()
    return result


class ReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reference = subprocess.check_output(
            ["git", "show", f"{TAG}:main.py"], cwd=ROOT,
        )
        cls.environment = dict(os.environ, PYTHONIOENCODING="utf-8")

    def test_workflow_against_tag(self):
        scenarios = (
            "inventory", "dry_run", "accepted", "mixed", "refused", "pending",
            "normalized_yes", "stale_name", "stale_count", "stale_path", "stale_flux",
            "duplicate_validation", "chain_conflict", "empty_mapping", "unknown_mapping",
            "duplicate_mapping", "no_source", "multiple_sources", "invalid_zip", "missing_output",
        )
        for scenario in scenarios:
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                base = Path(temp)
                old, new = base / "old", base / "new"
                prepare(old, scenario)
                shutil.copytree(old, new)
                reference = base / "reference.py"
                reference.write_bytes(self.reference)
                runs = []
                for folder, script in ((old, reference), (new, ROOT / "main.py")):
                    before = {p.name: hashlib.sha256(p.read_bytes()).digest()
                              for p in (folder / "input").glob("*")}
                    runs.append(subprocess.run(
                        [sys.executable, str(script)], cwd=folder,
                        env=self.environment, capture_output=True, timeout=30,
                    ))
                    after = {p.name: hashlib.sha256(p.read_bytes()).digest()
                             for p in (folder / "input").glob("*")}
                    self.assertEqual(before, after, "Le SGX source doit rester intact")
                self.assertEqual(runs[0].returncode, runs[1].returncode)
                self.assertEqual(runs[0].stdout, runs[1].stdout)
                # Les emplacements de traceback changent avec l'extraction.
                self.assertEqual(runs[0].stderr.splitlines()[-1:], runs[1].stderr.splitlines()[-1:])
                self.assertEqual(outputs(old), outputs(new))
                success = scenario in ("accepted", "mixed", "normalized_yes")
                self.assertEqual((new / "output/export_modifie.sgx").exists(), success)
                if success:
                    with zipfile.ZipFile(new / "input/export.sgx") as src, zipfile.ZipFile(new / "output/export_modifie.sgx") as dst:
                        self.assertEqual(src.namelist(), dst.namelist())
                        for info in src.infolist():
                            if info.filename not in (MODEL_A, MODEL_B):
                                self.assertEqual(src.read(info.filename), dst.read(info.filename))
                            copied = dst.getinfo(info.filename)
                            for attr in ("date_time", "compress_type", "external_attr", "extra", "comment"):
                                self.assertEqual(getattr(info, attr), getattr(copied, attr))
                        if scenario == "mixed":
                            self.assertEqual(src.read(MODEL_B), dst.read(MODEL_B))
                        model = json.loads(dst.read(MODEL_A))
                        self.assertEqual(trouver_lanes(model), ["C é", "C é", "B"])

    def test_recursive_lanes(self):
        shape = lane(" A ", [lane("A"), lane("B"), lane("")])
        self.assertEqual(trouver_lanes(shape), ["A", "A", "B"])
        self.assertEqual(renommer_lanes(shape, "A", "Nouveau"), 2)
        self.assertEqual(trouver_lanes(shape), ["Nouveau", "Nouveau", "B"])

    def test_distributed_app(self):
        """Le paquet copié à côté de main.py fonctionne sans installation."""
        with tempfile.TemporaryDirectory() as temp:
            app = Path(temp) / "app"
            prepare(app, "accepted")
            shutil.copyfile(ROOT / "main.py", app / "main.py")
            shutil.copytree(ROOT / "bpmn_script", app / "bpmn_script",
                            ignore=shutil.ignore_patterns("__pycache__"))
            source = (app / "input/export.sgx").read_bytes()
            run = subprocess.run([sys.executable, "main.py"], cwd=app,
                                 env=self.environment, capture_output=True, timeout=30)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertTrue((app / "output/export_modifie.sgx").exists())
            self.assertEqual((app / "input/export.sgx").read_bytes(), source)

    def test_model_path_identity(self):
        synthesis = construire_synthese([
            {"lane": "A", "flux": "Même nom", "fichier_modele": path}
            for path in (MODEL_A, MODEL_A, MODEL_B)
        ])
        self.assertEqual(synthesis["A"]["occurrences"], 3)
        models = synthesis["A"]["occurrences_par_modele"]
        self.assertEqual(models[MODEL_A]["occurrences"], 2)
        self.assertEqual(models[MODEL_B]["occurrences"], 1)

    def test_import_without_workflow(self):
        import runpy
        with tempfile.TemporaryDirectory() as temp, contextlib.redirect_stdout(io.StringIO()) as output:
            previous = Path.cwd()
            try:
                os.chdir(temp)
                runpy.run_path(str(ROOT / "main.py"), run_name="import_check")
                __import__("bpmn_script.workflow")
                self.assertEqual(list(Path(temp).iterdir()), [])
            finally:
                os.chdir(previous)
        self.assertEqual(output.getvalue(), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
