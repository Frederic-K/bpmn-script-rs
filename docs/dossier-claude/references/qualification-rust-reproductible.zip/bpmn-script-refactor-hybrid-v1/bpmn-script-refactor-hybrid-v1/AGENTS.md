# AGENTS.md — bpmn-script

## Projet

`bpmn-script` est un outil Python local destiné à analyser et modifier de
manière contrôlée des exports SAP Signavio `.sgx`.

Un `.sgx` est une archive ZIP contenant notamment des modèles JSON Signavio.

Le projet reste actuellement un outil Python local.

La mention éventuelle "BPMN Governance" correspond à une vision produit possible,
pas nécessairement au nom actuel du projet.

## Principes non négociables

Le workflow métier est :

extraction
→ analyse
→ décision humaine
→ modification contrôlée
→ contrôle

Respecter systématiquement :

- ne jamais écraser le SGX source ;
- conserver le dry-run avant modification ;
- conserver la validation humaine OUI/NON ;
- conserver le contrôle anti-altération du dry-run ;
- conserver le recomptage réel des modifications avant écriture ;
- utiliser le chemin interne exact du modèle comme identité technique ;
- ne jamais utiliser le nom du flux comme identité technique ;
- préserver les entrées SGX non modifiées ;
- rester 100 % local.

## Architecture et simplicité

Priorités :

KISS / YAGNI.

Ne pas ajouter sans besoin explicite :

- FastAPI ;
- Svelte ;
- PostgreSQL ;
- base de données ;
- serveur ;
- cloud ;
- ORM ;
- framework métier ;
- système de plugins ;
- abstraction générique anticipant un besoin futur.

La trajectoire technologique personnelle Svelte 5 + Python/FastAPI + PostgreSQL
ne constitue pas la roadmap technique de ce projet.

## Compatibilité

Le lancement utilisateur doit rester simple :

    python main.py

Le projet doit rester compatible avec le runtime Python portable Windows utilisé
sur clé USB.

Ne pas ajouter de dépendance Python sans justification explicite.

## Style de code

Privilégier :

- fonctions simples ;
- noms explicites ;
- responsabilités compréhensibles ;
- code Python lisible pour quelqu'un en apprentissage du langage ;
- séparation entre logique métier pure et accès fichiers lorsque cela apporte
  une vraie valeur ;
- dictionnaires existants tant qu'une autre structure n'apporte pas un bénéfice
  concret.

Ne pas sur-modulariser.

## Tests

Le tag de référence fonctionnelle est :

    v0.1-sgx-import-tested

Le test de non-régression principal est :

    python tests/test_reference.py

Lors d'une modification du comportement existant, exécuter les tests pertinents
avant de considérer la tâche terminée.

Les tests ne remplacent pas la qualification finale par import dans Signavio
lorsqu'un SGX généré est destiné à être adopté.

## Git

Ne jamais merger vers `main` sauf demande explicite.

Ne jamais déplacer ou réécrire le tag :

    v0.1-sgx-import-tested

Ne pas modifier l'historique Git existant.