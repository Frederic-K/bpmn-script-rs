# Utilisation avec Python portable Windows

Le refactoring conserve le lancement par `lancer.cmd` du package existant.
Le runtime et les dépendances restent inchangés (`openpyxl==3.1.5`,
`et_xmlfile==2.0.0`). Aucun serveur ni installation du projet n'est nécessaire.

Structure à distribuer :

```text
portable/
  lancer.cmd
  python/                 # Python embarqué existant et son fichier ._pth
  packages/               # Dépendances existantes
  app/
    main.py
    bpmn_script/          # Copier le dossier entier depuis cette branche
      __init__.py
      workflow.py
      regles.py
      sgx.py
      excel.py
    requirements.txt
    input/
    output/
    work/
```

Pour préparer un package de cette expérimentation, copier `main.py` **et**
`bpmn_script/` à côté l'un de l'autre dans `app/`, avec les dépendances et les
dossiers habituels. Ne pas mélanger un lanceur d'une version et les modules
d'une autre. Le dossier `portable/` est ignoré par Git ; sa copie locale existante
n'est pas mise à jour automatiquement par un changement de branche.

Le lanceur existant se place dans `app/`, puis exécute :

```bat
"..\python\python.exe" ".\main.py"
```

Le `main.py` ajoute son propre dossier au chemin d'import Python. Cela permet de
trouver `bpmn_script` même si le fichier `._pth` du Python embarqué exclut le
dossier du script. Le dossier courant des données n'est pas changé par Python.
La configuration portable locale observée contient `python314.zip`, `.`,
`..\packages`, `..\app`, avec `import site` désactivé ; aucune modification de
cette configuration n'est requise.

Le workflow Excel/SGX reste celui du [README.md](README.md). Les vérifications
de cette branche utilisent le Python embarqué local et une copie temporaire de
`main.py` avec son paquet. Vos fichiers `portable/app/input`, `work` et `output`
ne sont pas utilisés par les tests.
