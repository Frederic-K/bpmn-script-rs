# bpmn-script

Outil Python local pour inventorier les swimlanes d'un export SAP Signavio
`.sgx`, préparer des renommages, recueillir une validation humaine et produire
une nouvelle archive. Aucun service réseau ni base de données.

Cette branche expérimentale `codex-refactor-v1` part du tag stable
`v0.1-sgx-import-tested`. Voir [REFACTORING.md](REFACTORING.md) pour les choix,
les compromis et les vérifications. Le tag reste la référence fonctionnelle.

## Lancement sous Windows

Depuis la racine du projet, avec Python installé :

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

Conserver `main.py` et le dossier `bpmn_script/` ensemble. Créer les dossiers
`input/`, `output/` et `work/` avant le lancement, comme dans la version de référence.
Les chemins de traitement restent relatifs au dossier courant.
Pour le Python embarqué : [README_PORTABLE.md](README_PORTABLE.md).

## Workflow conservé

1. Placer exactement un `.sgx` dans `input/`, puis lancer `main.py`.
2. Copier `output/inventaire_swimlanes.xlsx` vers
   `work/correspondance_swimlanes.xlsx`. Remplir seulement **Nouveau nom** ;
   laisser vide pour ne rien demander. Enregistrer et fermer le classeur.
3. Relancer : le dry-run génère `output/analyse_modifications.xlsx`.
4. Copier ce fichier vers `work/validation_modifications.xlsx`. Remplir seulement
   **Validation** avec `OUI` ou `NON`, puis enregistrer et fermer.
5. Relancer : consulter `output/controle_validation.xlsx`. Les propositions
   approuvées et conformes sont testées en mémoire. L'archive
   `output/<nom_source>_modifie.sgx` n'est écrite que si les décomptes sont conformes
   et qu'au moins une modification est validée. La source reste dans `input/`.
6. Vérifier les rapports puis importer le résultat dans un dossier Signavio de test.

Le chemin du modèle dans l'archive constitue son identité technique, même si deux
modèles portent le même nom. Ne pas modifier les autres colonnes des Excel.
Les JSON de `output/` tracent l'extraction, la synthèse, les correspondances,
le dry-run et les modifications validées ou ignorées.

Avant un nouveau cycle, archiver les résultats utiles, retirer les anciens fichiers
de `work/` et `output/`, et remplacer le SGX source. Une ancienne validation peut
sinon être relue automatiquement. Si les correspondances ou la source changent,
refaire la validation depuis une nouvelle analyse. Un ancien SGX de sortie peut
subsister après un lancement sans génération : vérifier les messages et sa date.

## Tests locaux

```powershell
.\.venv\Scripts\python.exe tests\test_reference.py
# Ou avec le Python portable présent dans ce dépôt :
.\portable\python\python.exe tests\test_reference.py
```

Les tests utilisent `unittest`, `openpyxl`, Git et le tag local de référence.
Ils génèrent uniquement des données synthétiques dans des dossiers temporaires.
Aucun accès à Signavio ni téléchargement pendant les tests.
