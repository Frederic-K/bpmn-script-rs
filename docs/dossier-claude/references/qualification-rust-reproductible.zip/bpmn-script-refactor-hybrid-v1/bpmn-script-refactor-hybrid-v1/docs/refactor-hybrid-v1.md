# Refactor hybride V1

## Objectif

Produire le candidat de refactoring V1 de `bpmn-script` à partir de la branche
`codex-refactor-v1`.

Le comportement fonctionnel doit rester strictement identique au tag
`v0.1-sgx-import-tested`.

Ce travail est un refactoring structurel, pas une évolution fonctionnelle.

## Architecture cible

```text
main.py

bpmn_script/
├── __init__.py
├── workflow.py
├── lanes.py
├── regles.py
├── sgx.py
└── excel.py

tests/
└── test_reference.py
```

## Base à conserver depuis `codex-refactor-v1`

Conserver :

- `main.py` comme lanceur minimal ;
- `workflow.py` comme orchestration linéaire ;
- la séparation logique métier / I/O ;
- le package `bpmn_script` ;
- `regles.py` pour les règles pures ;
- `sgx.py` pour les accès à l'archive SGX ;
- `excel.py` pour les entrées/sorties Excel ;
- `tests/test_reference.py` ;
- le correctif de compatibilité du runtime Python portable Windows ;
- l'absence de nouvelles dépendances ;
- les dictionnaires actuels ;
- le workflow et les messages existants.

## Changements demandés

### 1. Extraire les règles de lanes

Déplacer depuis `regles.py` vers `lanes.py` :

- `trouver_lanes` ;
- `renommer_lanes`.

Adapter uniquement les imports nécessaires.

Aucun changement de comportement.

### 2. Factoriser la mise en forme Excel

Dans `excel.py`, supprimer la duplication de mise en forme en introduisant
les helpers simples utilisés dans l'approche Claude :

- `_mettre_en_forme_entete(feuille)` ;
- `_retour_ligne(cellule)` ;
- une constante unique `REMPLISSAGE_SAISIE`.

Le rendu Excel doit rester strictement identique à la référence.

### 3. Convention des fichiers modèle Signavio

Ne pas créer de `config.py`.

Définir simplement dans `sgx.py`, au même endroit :

```python
NOM_FICHIER_MODELE = "model_1_.json"
NOM_FICHIER_META = "model_meta.json"
```

Utiliser ces constantes dans ce module.

Ne pas changer la logique de détection des modèles pendant ce refactoring.

## Explicitement hors périmètre

Ne pas :

- corriger des comportements fonctionnels existants ;
- modifier la logique `.strip()` ;
- ajouter la détection des lanes vides ;
- modifier la règle `model_1_.json` ;
- ajouter des dataclasses ;
- ajouter du typage massif ;
- ajouter `config.py` ;
- ajouter `io_json.py` ;
- séparer `excel.py` en plusieurs modules ;
- ajouter FastAPI, Svelte ou PostgreSQL ;
- ajouter une nouvelle interface ;
- modifier les formats Excel ou JSON ;
- nettoyer automatiquement les dossiers ;
- modifier les règles de validation humaine.

Les améliorations fonctionnelles éventuelles feront l'objet de travaux séparés.

## Validation attendue

Exécuter :

```sh
python tests/test_reference.py
```

La suite doit rester verte.

Vérifier également que :

- `python main.py` reste le point d'entrée ;
- le package peut être copié avec `main.py` pour le runtime portable ;
- le SGX source reste inchangé ;
- aucun nouveau package Python n'est requis.

## Livrable Git

Créer une branche `refactor-hybrid-v1` à partir de `codex-refactor-v1`.

Effectuer uniquement les modifications décrites dans ce document.

Effectuer un commit final explicite.

Ne merger aucune branche vers `main`.

## Compte rendu attendu

À la fin, indiquer :

- les fichiers modifiés ;
- les choix appliqués ;
- les éléments volontairement laissés inchangés ;
- les tests exécutés ;
- le résultat des tests ;
- les éventuels points nécessitant encore une validation humaine ou Signavio.
