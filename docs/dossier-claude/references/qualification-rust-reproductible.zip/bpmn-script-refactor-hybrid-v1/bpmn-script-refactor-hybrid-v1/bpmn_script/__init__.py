"""Outil local de renommage des swimlanes dans les exports SGX."""
