"""Lecture des décisions humaines et présentation des trois rapports Excel."""

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation


REMPLISSAGE_SAISIE = PatternFill(fill_type="solid", fgColor="FFF2CC")


def _mettre_en_forme_entete(feuille):
    """Mettre l'en-tête en gras, le figer et activer le filtre."""
    for cellule in feuille[1]:
        cellule.font = Font(bold=True)

    feuille.freeze_panes = "A2"
    feuille.auto_filter.ref = feuille.dimensions


def _retour_ligne(cellule):
    """Activer le retour à la ligne et aligner le contenu en haut."""
    cellule.alignment = Alignment(wrap_text=True, vertical="top")


def ecrire_inventaire(synthese):
    """Produire le modèle de correspondance avec la présentation de référence."""
    classeur = Workbook()

    feuille = classeur.active
    feuille.title = "Correspondance"

    feuille.append([
        "Nom actuel",
        "Nouveau nom",
        "Occurrences",
        "Nombre de flux",
        "Flux concernés",
        "Flux avec occurrences multiples"
    ])


    for lane, infos in sorted(synthese.items()):
        multiples = [
            f"{flux} ({nombre})"
            for flux, nombre in infos["occurrences_par_flux"].items()
            if nombre > 1
        ]

        feuille.append([
            lane,
            "",
            infos["occurrences"],
            len(infos["flux"]),
            ", ".join(infos["flux"]),
            ", ".join(multiples)
        ])


    # Mise en forme minimale pour faciliter le travail dans Excel
    _mettre_en_forme_entete(feuille)

    feuille.column_dimensions["A"].width = 35
    feuille.column_dimensions["B"].width = 35
    feuille.column_dimensions["C"].width = 15
    feuille.column_dimensions["D"].width = 18
    feuille.column_dimensions["E"].width = 90
    feuille.column_dimensions["F"].width = 90

    for ligne in feuille.iter_rows(min_row=2):
        _retour_ligne(ligne[4])
        _retour_ligne(ligne[5])

    for cellule in feuille["B"][1:]:
        cellule.fill = REMPLISSAGE_SAISIE


    classeur.save("output/inventaire_swimlanes.xlsx")

    print("[OK] Excel généré : output/inventaire_swimlanes.xlsx")


def lire_correspondances(fichier_correspondance):
    """Lire les nouveaux noms, en conservant les règles de nettoyage existantes."""
    classeur_lu = load_workbook(fichier_correspondance)

    feuille_lue = classeur_lu["Correspondance"]

    correspondances = {}

    for ligne in feuille_lue.iter_rows(min_row=2, values_only=True):
        nom_actuel = ligne[0]
        nouveau_nom = ligne[1]

        if isinstance(nouveau_nom, str):
            nouveau_nom = nouveau_nom.strip()

        if nouveau_nom:
            correspondances[nom_actuel] = nouveau_nom
    classeur_lu.close()
    return correspondances


def ecrire_analyse(analyse_modifications):
    """Produire le dry-run et sa colonne de validation OUI/NON."""
    classeur_analyse = Workbook()

    feuille_analyse = classeur_analyse.active
    feuille_analyse.title = "Analyse"

    feuille_analyse.append([
        "Flux",
        "Nom actuel",
        "Nouveau nom",
        "Occurrences",
        "Validation",
        "Fichier modèle"
    ])


    for modification in analyse_modifications:
        feuille_analyse.append([
            modification["flux"],
            modification["nom_actuel"],
            modification["nouveau_nom"],
            modification["occurrences"],
            "",
            modification["fichier_modele"]
        ])


    _mettre_en_forme_entete(feuille_analyse)

    feuille_analyse.column_dimensions["A"].width = 70
    feuille_analyse.column_dimensions["B"].width = 35
    feuille_analyse.column_dimensions["C"].width = 35
    feuille_analyse.column_dimensions["D"].width = 15
    feuille_analyse.column_dimensions["E"].width = 15
    feuille_analyse.column_dimensions["F"].width = 250

    for ligne in feuille_analyse.iter_rows(min_row=2):
        _retour_ligne(ligne[0])
        _retour_ligne(ligne[5])

    for cellule in feuille_analyse["E"][1:]:
        cellule.fill = REMPLISSAGE_SAISIE


    validation_oui_non = DataValidation(
        type="list",
        formula1='"OUI,NON"',
        allow_blank=True
    )

    feuille_analyse.add_data_validation(
        validation_oui_non
    )

    validation_oui_non.add(
        f"E2:E{feuille_analyse.max_row}"
    )


    classeur_analyse.save(
        "output/analyse_modifications.xlsx"
    )


    print(
        "[OK] Excel d'analyse généré : "
        "output/analyse_modifications.xlsx"
    )


def lire_validation(fichier_validation):
    """Lire les lignes sans transformer les valeurs saisies."""
    classeur = load_workbook(fichier_validation)
    feuille = classeur["Analyse"]
    lignes = list(feuille.iter_rows(min_row=2, values_only=True))
    classeur.close()
    return lignes


def ecrire_controle(controle_validation):
    """Présenter toutes les décisions et les motifs du contrôle."""
    classeur_controle = Workbook()

    feuille_controle = classeur_controle.active
    feuille_controle.title = "Contrôle"

    feuille_controle.append([
        "Ligne validation",
        "Flux",
        "Nom actuel",
        "Nouveau nom saisi",
        "Nouveau nom attendu",
        "Occurrences",
        "Validation",
        "Résultat",
        "Motif",
        "Fichier modèle"
    ])

    for controle in controle_validation:
        feuille_controle.append([
            controle["ligne_validation"],
            controle["flux"],
            controle["nom_actuel"],
            controle["nouveau_nom_saisi"],
            controle["nouveau_nom_attendu"],
            controle["occurrences"],
            controle["validation"],
            controle["resultat"],
            controle["motif"],
            controle["fichier_modele"]
        ])

    _mettre_en_forme_entete(feuille_controle)

    feuille_controle.column_dimensions["A"].width = 18
    feuille_controle.column_dimensions["B"].width = 70
    feuille_controle.column_dimensions["C"].width = 35
    feuille_controle.column_dimensions["D"].width = 35
    feuille_controle.column_dimensions["E"].width = 35
    feuille_controle.column_dimensions["F"].width = 15
    feuille_controle.column_dimensions["G"].width = 15
    feuille_controle.column_dimensions["H"].width = 18
    feuille_controle.column_dimensions["I"].width = 40
    feuille_controle.column_dimensions["J"].width = 250

    for ligne in feuille_controle.iter_rows(min_row=2):
        _retour_ligne(ligne[1])
        _retour_ligne(ligne[8])
        _retour_ligne(ligne[9])

    classeur_controle.save(
        "output/controle_validation.xlsx"
    )

    print(
        "[OK] Rapport de contrôle généré : "
        "output/controle_validation.xlsx"
    )
