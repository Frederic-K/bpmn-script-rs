"""Parcours et renommage des lanes dans les modèles en mémoire."""


def trouver_lanes(shape):
    """Recenser récursivement les noms non vides des lanes."""
    lanes = []

    if shape.get("stencil", {}).get("id") == "Lane":
        nom = shape.get("properties", {}).get("name", "").strip()

        if nom:
            lanes.append(nom)

    for enfant in shape.get("childShapes", []):
        lanes.extend(trouver_lanes(enfant))

    return lanes

def renommer_lanes(shape, nom_actuel, nouveau_nom):
    """Renommer dans le modèle en mémoire et compter les occurrences touchées."""
    nombre_modifications = 0

    if shape.get("stencil", {}).get("id") == "Lane":
        nom = shape.get("properties", {}).get("name", "")

        if isinstance(nom, str) and nom.strip() == nom_actuel:
            shape["properties"]["name"] = nouveau_nom
            nombre_modifications += 1

    for enfant in shape.get("childShapes", []):
        nombre_modifications += renommer_lanes(
            enfant,
            nom_actuel,
            nouveau_nom
        )

    return nombre_modifications
