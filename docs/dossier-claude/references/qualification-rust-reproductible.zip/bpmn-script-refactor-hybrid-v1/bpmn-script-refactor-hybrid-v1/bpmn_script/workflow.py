"""Enchaînement local des étapes selon les fichiers présents dans work/."""

import json
from pathlib import Path

from .excel import (
    ecrire_analyse, ecrire_controle, ecrire_inventaire,
    lire_correspondances, lire_validation,
)
from .regles import construire_synthese, controler_validation, preparer_analyse
from .sgx import ecrire_sgx, extraire_lanes, preparer_modeles, selectionner_sgx


def sauvegarder_json(nom, donnees):
    """Écrire un rapport JSON avec le format historique."""
    with open(f"output/{nom}", "w", encoding="utf-8") as fichier:
        json.dump(donnees, fichier, ensure_ascii=False, indent=2)
    print(f"[OK] {nom} généré")


def executer():
    """Poursuivre le workflow jusqu'à l'étape autorisée par les fichiers humains."""
    sgx = selectionner_sgx()
    print(f"[OK] Fichier SGX sélectionné : {sgx.name}")

    resultats = extraire_lanes(sgx)
    print(f"[OK] Extraction terminée : {len(resultats)} occurrences")
    sauvegarder_json("resultats.json", resultats)

    synthese = construire_synthese(resultats)
    print(f"[OK] Synthèse terminée : {len(synthese)} lanes uniques")
    sauvegarder_json("synthese.json", synthese)
    ecrire_inventaire(synthese)

    fichier_correspondance = Path("work/correspondance_swimlanes.xlsx")
    if not fichier_correspondance.exists():
        print(
            "[INFO] Aucun fichier de correspondance trouvé : "
            "la préparation des modifications est ignorée"
        )
        return

    correspondances = lire_correspondances(fichier_correspondance)
    print(f"[OK] Correspondances chargées : {len(correspondances)}")
    sauvegarder_json("correspondances.json", correspondances)
    analyse = preparer_analyse(correspondances, synthese)
    print(f"[OK] Dry-run préparé : {len(analyse)} impacts flux/lane")
    sauvegarder_json("analyse_modifications.json", analyse)
    ecrire_analyse(analyse)

    fichier_validation = Path("work/validation_modifications.xlsx")
    if not fichier_validation.exists():
        print(
            "[INFO] Aucun fichier de validation trouvé : "
            "aucune modification autorisée"
        )
        return

    lignes = lire_validation(fichier_validation)
    validees, ignorees, controle = controler_validation(lignes, analyse)
    print(f"[OK] Modifications validées : {len(validees)}")
    sauvegarder_json("modifications_validees.json", validees)
    sauvegarder_json("modifications_ignorees.json", ignorees)
    ecrire_controle(controle)

    modeles, conformes = preparer_modeles(sgx, validees)
    if conformes and validees:
        ecrire_sgx(sgx, modeles)
