"""Règles sur les modèles et propositions, sans accès aux fichiers."""


def construire_synthese(resultats):
    """Compter les lanes en conservant le chemin comme identité du modèle."""
    synthese = {}

    for resultat in resultats:
        lane = resultat["lane"]
        flux = resultat["flux"]
        fichier_modele = resultat["fichier_modele"]

        if lane not in synthese:
            synthese[lane] = {
                "occurrences": 0,
                "flux": [],
                "occurrences_par_flux": {},
                "occurrences_par_modele": {}
            }

        synthese[lane]["occurrences"] += 1

        if flux not in synthese[lane]["flux"]:
            synthese[lane]["flux"].append(flux)

        if flux not in synthese[lane]["occurrences_par_flux"]:
            synthese[lane]["occurrences_par_flux"][flux] = 0

        synthese[lane]["occurrences_par_flux"][flux] += 1

        if fichier_modele not in synthese[lane]["occurrences_par_modele"]:
            synthese[lane]["occurrences_par_modele"][fichier_modele] = {
                "flux": flux,
                "occurrences": 0
            }

        synthese[lane]["occurrences_par_modele"][
            fichier_modele
        ]["occurrences"] += 1
    return synthese


def preparer_analyse(correspondances, synthese):
    """Préparer les impacts sans modifier les modèles."""
    analyse_modifications = []

    for nom_actuel, nouveau_nom in correspondances.items():
        if nom_actuel in synthese:
            infos = synthese[nom_actuel]

            for fichier_modele, infos_modele in infos[
                "occurrences_par_modele"
            ].items():
                analyse_modifications.append({
                    "fichier_modele": fichier_modele,
                    "flux": infos_modele["flux"],
                    "nom_actuel": nom_actuel,
                    "nouveau_nom": nouveau_nom,
                    "occurrences": infos_modele["occurrences"]
                })
    return analyse_modifications


def controler_validation(lignes, analyse_modifications):
    """Comparer chaque décision au dry-run courant ; conserver les refus et attentes."""
    modifications_validees = []
    modifications_ignorees = []
    controle_validation = []

    propositions_attendues = {
        (
            modification["fichier_modele"],
            modification["flux"],
            modification["nom_actuel"],
            modification["nouveau_nom"],
            modification["occurrences"],
        )
        for modification in analyse_modifications
    }

    attendus_par_ligne = {
        (
            modification["fichier_modele"],
            modification["flux"],
            modification["nom_actuel"],
            modification["occurrences"]
        ): modification["nouveau_nom"]
        for modification in analyse_modifications
    }

    for numero_ligne, ligne in enumerate(
        lignes,
        start=2
    ):
        flux = ligne[0]
        nom_actuel = ligne[1]
        nouveau_nom = ligne[2]
        occurrences = ligne[3]
        validation = ligne[4]
        fichier_modele = ligne[5]

        cle_attendue = (
            fichier_modele,
            flux,
            nom_actuel,
            occurrences
        )

        nouveau_nom_attendu = attendus_par_ligne.get(
            cle_attendue
        )

        if isinstance(validation, str):
            validation = validation.strip().upper()

        if validation == "OUI":
            proposition = (
                fichier_modele,
                flux,
                nom_actuel,
                nouveau_nom,
                occurrences
            )

            if proposition in propositions_attendues:
                modifications_validees.append({
                    "fichier_modele": fichier_modele,
                    "flux": flux,
                    "nom_actuel": nom_actuel,
                    "nouveau_nom": nouveau_nom,
                    "occurrences": occurrences
                })

                resultat = "VALIDÉE"
                motif = "Conforme au dry-run"

            else:
                modifications_ignorees.append({
                    "fichier_modele": fichier_modele,
                    "flux": flux,
                    "nom_actuel": nom_actuel,
                    "nouveau_nom": nouveau_nom,
                    "occurrences": occurrences,
                    "motif": "Ne correspond plus au dry-run"
                })

                resultat = "IGNORÉE"
                motif = "Ne correspond plus au dry-run"

                print(
                    "[ATTENTION] Une ligne validée ne correspond "
                    "plus au dry-run : modification ignorée"
                )

        elif validation == "NON":
            resultat = "NON VALIDÉE"
            motif = "Refus humain"

        else:
            resultat = "EN ATTENTE"
            motif = "Aucune validation renseignée"

        controle_validation.append({
            "ligne_validation": numero_ligne,
            "flux": flux,
            "nom_actuel": nom_actuel,
            "nouveau_nom_saisi": nouveau_nom,
            "nouveau_nom_attendu": nouveau_nom_attendu,
            "occurrences": occurrences,
            "validation": validation,
            "resultat": resultat,
            "motif": motif,
            "fichier_modele": fichier_modele,
        })
    return modifications_validees, modifications_ignorees, controle_validation
