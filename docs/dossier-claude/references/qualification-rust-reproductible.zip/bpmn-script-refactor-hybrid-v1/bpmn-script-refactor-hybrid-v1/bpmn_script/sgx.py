"""Lecture SGX, contrôle en mémoire et copie de l’archive en sortie."""

from pathlib import Path
import json
import zipfile

from .lanes import trouver_lanes, renommer_lanes


NOM_FICHIER_MODELE = "model_1_.json"
NOM_FICHIER_META = "model_meta.json"


def selectionner_sgx():
    """Exiger exactement un SGX dans input/."""
    fichiers_sgx = list(
        Path("input").glob("*.sgx")
    )

    if len(fichiers_sgx) == 0:
        raise FileNotFoundError(
            "Aucun fichier SGX trouvé dans input/"
        )

    if len(fichiers_sgx) > 1:
        raise RuntimeError(
            "Plusieurs fichiers SGX trouvés dans input/ : "
            "un seul fichier est attendu"
        )

    sgx = fichiers_sgx[0]
    return sgx


def extraire_lanes(sgx):
    """Lire les modèles et leurs métadonnées sans modifier la source."""
    resultats = []

    # Extraction des lanes depuis le SGX
    with zipfile.ZipFile(sgx) as archive:
        print("[OK] Archive SGX ouverte")

        fichiers_modeles = [
            chemin for chemin in archive.namelist()
            if chemin.endswith(NOM_FICHIER_MODELE)
        ]

        for fichier_modele in fichiers_modeles:
            fichier_meta = fichier_modele.replace(
                NOM_FICHIER_MODELE,
                NOM_FICHIER_META
            )

            contenu_meta = archive.read(fichier_meta).decode("utf-8")
            meta = json.loads(contenu_meta)

            nom_flux = meta.get("name", "")

            contenu_modele = archive.read(fichier_modele).decode("utf-8")
            modele = json.loads(contenu_modele)

            lanes = trouver_lanes(modele)

            for lane in lanes:
                resultats.append({
                    "fichier_modele": fichier_modele,
                    "flux": nom_flux,
                    "lane": lane
                })
    return resultats


def preparer_modeles(sgx, modifications_validees):
    """Appliquer en mémoire et vérifier chaque nombre d’occurrences attendu."""
    modeles_modifies = {}
    modifications_conformes = True

    with zipfile.ZipFile(sgx) as archive:
        for modification in modifications_validees:
            fichier_modele = modification["fichier_modele"]

            if fichier_modele not in modeles_modifies:
                contenu_modele = archive.read(
                    fichier_modele
                ).decode("utf-8")

                modeles_modifies[fichier_modele] = json.loads(
                    contenu_modele
                )

            modele = modeles_modifies[fichier_modele]

            nombre_modifications = renommer_lanes(
                modele,
                modification["nom_actuel"],
                modification["nouveau_nom"]
            )

            occurrences_attendues = modification["occurrences"]

            if nombre_modifications == occurrences_attendues:
                print(
                    "[OK] Test en mémoire conforme : "
                    f"{nombre_modifications} modification(s)"
                )
            else:
                modifications_conformes = False

                print(
                    "[ATTENTION] Test en mémoire non conforme : "
                    f"{nombre_modifications} trouvée(s), "
                    f"{occurrences_attendues} attendue(s)"
                )
    return modeles_modifies, modifications_conformes


def ecrire_sgx(sgx, modeles_modifies):
    """Écrire uniquement dans output/ en recopiant les entrées ZIP et leurs attributs."""
    fichier_sgx_modifie = (
        Path("output")
        / f"{sgx.stem}_modifie.sgx"
    )

    with zipfile.ZipFile(sgx, "r") as archive_source:
        with zipfile.ZipFile(
            fichier_sgx_modifie,
            "w"
        ) as archive_sortie:

            for info in archive_source.infolist():
                contenu = archive_source.read(
                    info.filename
                )

                if info.filename in modeles_modifies:
                    contenu = json.dumps(
                        modeles_modifies[info.filename],
                        ensure_ascii=False
                    ).encode("utf-8")

                archive_sortie.writestr(
                    info,
                    contenu
                )

    print(
        "[OK] SGX modifié généré : "
        f"{fichier_sgx_modifie}"
    )
