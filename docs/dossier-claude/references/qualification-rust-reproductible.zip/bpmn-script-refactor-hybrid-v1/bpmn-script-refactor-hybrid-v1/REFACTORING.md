# Expérimentation indépendante codex-refactor-v1

## Référence et analyse initiale

Départ : `v0.1-sgx-import-tested`, commit
`63f17c7fcef5f2ee1a1882182e0509836593ec48`. La branche a été créée directement
depuis ce tag. Aucune consultation de `claude-refactor-v1` ou `refactor-v1`.

Le script de référence comporte 717 lignes et exécute toutes les étapes à
l'import. Il mélange parcours JSON, regroupements, présentation Excel, contrôle
humain et réécriture ZIP, avec des dépendances implicites entre blocs imbriqués.
Les garde-fous et l'identité par chemin sont déjà présents : il faut les déplacer,
sans redéfinir leurs règles.

`README.md` et `main.py` ont été lus avant les changements. `product.md`,
`session.md` et `README_PORTABLE.md` étaient absents des fichiers locaux recherchés.
Le tag ne contient pas de README. Les deux guides de cette branche sont donc
documentés ici sans faire dépendre l'expérience d'une autre branche.
« BPMN Governance » n'impose ni nom ni architecture ; aucune trajectoire
Svelte/FastAPI/PostgreSQL n'est appliquée à cet outil.

Plan annoncé avant modification : extraire les fonctions, séparer les E/S,
garder une orchestration linéaire, comparer au tag, vérifier le portable et
documenter avant commit.

## Arborescence et choix

```text
main.py                    # Point d'entrée, 12 lignes
bpmn_script/
  __init__.py              # Paquet Python ordinaire
  workflow.py              # Étapes et écriture des rapports JSON
  regles.py                # Parcours, synthèse, dry-run, contrôle des décisions
  sgx.py                   # Lecture ZIP, essais en mémoire, copie en sortie
  excel.py                 # Lecture des décisions et trois rapports Excel
tests/
  test_reference.py        # Comparaison exécutable avec le tag et tests ciblés
requirements.txt           # Inchangé
README.md
README_PORTABLE.md
REFACTORING.md
input/ output/ work/       # Données locales, non suivies
```

- **Un paquet plat, quatre modules de travail** : responsabilités visibles sans
  multiplier les niveaux. Aucun besoin d'installer le paquet. `main.py` garde
  la commande habituelle et rend l'import compatible avec le Python embarqué.
- **Un orchestrateur linéaire** : on lit les étapes dans l'ordre du workflow.
  Les retours anticipés remplacent les imbrications aux étapes sans fichier humain.
  Le contrôle en mémoire reste obligatoire avant l'écriture de l'archive.
- **Des fonctions et les dictionnaires existants** : les données sont passées
  explicitement ; pas de classes artificielles ni nouveau format. Les règles
  peuvent être testées sans archive ni Excel. Seul un avertissement console est
  conservé dans le contrôle des décisions pour garder l'ordre des messages.
- **Un module SGX** : il conserve la sélection unique, les modèles en mémoire,
  les décomptes et les attributs des entrées ZIP. La source est ouverte en lecture ;
  le chemin de destination reste calculé dans `output/`.
- **Un module Excel** : il concentre `openpyxl` et garde exactement les colonnes,
  styles, filtres et validations de saisie. Les trois mises en forme restent
  explicites pour permettre de les apprendre et les modifier séparément.
- **Une petite fonction JSON dans le workflow** : mutualisation du format
  historique, sans créer un module utilitaire pour une seule fonction.
- **Tests avec unittest** : aucune dépendance ajoutée. Le script du tag sert
  d'oracle local ; les tests ciblés donnent aussi des assertions indépendantes.

Pour apprendre : commencer par `trouver_lanes` et `renommer_lanes`, puis la
synthèse et le dry-run dans `regles.py`, ensuite les E/S, enfin `executer()`.

## Compromis et exclusions volontaires

L'extraction privilégie la fidélité au code connu plutôt qu'une réécriture
algorithmique. Les noms français et les dictionnaires sont conservés. Les
fonctions de présentation restent assez longues et quelques `print` restent
dans les E/S. Le total de code ne diminue pas nécessairement : les interfaces
explicites et la documentation remplacent les dépendances globales implicites.

Le programme lancé garde ses effets ; importer `main.py` ou un module ne lance
plus le traitement. C'est le changement structurel nécessaire aux tests.
Les numéros de lignes et piles d'erreurs changent avec la séparation.
La lecture de validation matérialise les lignes dans une liste avant le contrôle.

Les particularités existantes sont conservées : normalisation de `OUI`, dernier
renommage gagnant pour une correspondance dupliquée, rejet individuel d'un `OUI`
obsolète, absence de nettoyage automatique des sorties, application séquentielle
des renommages (un conflit peut faire échouer le décompte et empêcher la sortie).
Pas de nouvelle interprétation des cellules invalides ni de validation globale
supplémentaire des classeurs. Les répertoires doivent toujours être préparés.

Volontairement non réalisés : API, interface web, FastAPI, Svelte, PostgreSQL,
autre base de données, appels réseau, framework métier ou de tests supplémentaire,
ORM, conteneur d'injection, système de plugins, configuration générique, nouveaux
arguments de commande, packaging installable, journalisation refondue, migration
des formats, nettoyage automatique et corrections fonctionnelles opportunistes.
Aucune fusion vers `main`, aucun déplacement du tag, aucune publication.

## Vérification et limites

Commande : `portable\python\python.exe tests\test_reference.py`.
Runtime local : Python embarqué Windows 3.14.7, openpyxl 3.1.5.
Résultat le 5 septembre 2026 : les 5 tests passent, dont la comparaison des
20 scénarios avec le tag (15,277 secondes pour la suite complète).

La suite compare 20 scénarios avec le script extrait directement du tag :
inventaire, dry-run, validation complète ou partielle, refus, attente,
normalisation de `OUI`, nom/chemin/flux/décompte obsolètes, validation dupliquée,
renommages en conflit, correspondance vide/inconnue/dupliquée, absence ou
multiplicité des sources, ZIP invalide et absence du dossier de sortie.

Comparaisons : code de retour, messages console, type/message final des erreurs,
liste des sorties, JSON et SGX octet par octet, tous les composants XML Excel
(seuls les horodatages de création/modification sont neutralisés). Les tests
vérifient aussi l'intégrité SHA-256 des sources, les entrées non modifiées et les
attributs ZIP, la récursivité et l'identité de deux modèles homonymes.
Une copie temporaire distribuable `app/main.py` + `app/bpmn_script/` est exécutée
avec le même runtime. Un test vérifie l'absence d'effets lors de l'import.

Ces tests caractérisent les scénarios couverts ; ils ne prouvent pas l'équivalence
pour toute entrée possible. Aucun nouvel import Signavio n'est réalisé dans cette
expérience locale. Le tag conserve sa qualification d'import testé ; cette branche
devra être contrôlée dans Signavio avant adoption. Le package portable local
existant et les données réelles de traitement n'ont pas été remplacés.
