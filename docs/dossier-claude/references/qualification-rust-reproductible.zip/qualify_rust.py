"""Black-box qualification of the original Rust CLI against supplied Python.

Usage: python qualify_rust.py --root REVIEW_DIRECTORY [--binary EXE]
Requires openpyxl. No production source is edited. All fixtures are copies.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile
from openpyxl import load_workbook

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
parser.add_argument('--binary', type=Path)
args = parser.parse_args()
root = args.root.resolve()
hybrid = root / 'bpmn-script-refactor-hybrid-v1/bpmn-script-refactor-hybrid-v1'
stable = root / 'bpmn-script-main/bpmn-script-main/main.py'
binary = args.binary or root / 'bpmn-script-rs-main/bpmn-script-rs-main/target/debug/bpmn-script-rs.exe'
spec = importlib.util.spec_from_file_location('fixtures', hybrid / 'tests/test_reference.py')
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
import sys

SCENARIOS = ['inventory', 'dry_run', 'accepted', 'mixed', 'refused', 'pending',
 'normalized_yes', 'stale_name', 'stale_count', 'stale_path', 'stale_flux',
 'duplicate_validation', 'chain_conflict', 'empty_mapping', 'unknown_mapping',
 'duplicate_mapping', 'no_source', 'multiple_sources', 'invalid_zip', 'missing_output']
EXTRA = ['partial', 'numeric_old', 'numeric_new', 'formula_new', 'null_name',
 'bad_children', 'duplicate_different', 'old_output', 'zip_attributes', 'same_name']
out = root / 'qualification-runs'
out.mkdir(exist_ok=True)

def hashfile(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def edit_archive(path, change, attributes=False):
    with zipfile.ZipFile(path) as z:
        entries = [(info, z.read(info)) for info in z.infolist()]
    with zipfile.ZipFile(path, 'w') as z:
        if attributes:
            z.comment = b'archive-comment'
        for info, content in entries:
            if info.filename == fixtures.MODEL_A:
                data = json.loads(content)
                change(data)
                content = json.dumps(data, ensure_ascii=False).encode('utf-8')
                if attributes:
                    info.comment = b'model-comment'
                    info.extra = b'\xfe\xca\x02\x00OK'
                    info.create_system = 0
                    info.external_attr = 0x20
            z.writestr(info, content)

def modify_book(path, operation):
    book = load_workbook(path)
    operation(book.active)
    book.save(path)
    book.close()

def prepare(folder, name):
    fixtures.prepare(folder, name if name in SCENARIOS else 'accepted')
    mapping = folder / 'work/correspondance_swimlanes.xlsx'
    validation = folder / 'work/validation_modifications.xlsx'
    if name == 'partial':
        modify_book(validation, lambda s: s.delete_rows(3))
    if name == 'numeric_old':
        edit_archive(folder / 'input/export.sgx', lambda d: d['childShapes'][0]['properties'].update(name='123'))
        modify_book(mapping, lambda s: setattr(s['A2'], 'value', 123))
    if name in ('numeric_new', 'formula_new', 'same_name'):
        value = {'numeric_new': 123, 'formula_new': '="Z"', 'same_name': 'A'}[name]
        modify_book(mapping, lambda s: setattr(s['B2'], 'value', value))
        def update(s):
            s['C2'], s['C3'] = value, value
        modify_book(validation, update)
    if name == 'null_name':
        edit_archive(folder / 'input/export.sgx', lambda d: d['childShapes'][0]['properties'].update(name=None))
    if name == 'bad_children':
        edit_archive(folder / 'input/export.sgx', lambda d: d.update(childShapes=7))
    if name == 'duplicate_different':
        modify_book(mapping, lambda s: s.append(['A', 'D']))
    if name == 'old_output':
        modify_book(validation, lambda s: [setattr(s[c], 'value', 'NON') for c in ['E2', 'E3']])
        (folder / 'output/export_modifie.sgx').write_bytes(b'OLD-OUTPUT-SENTINEL')
    if name == 'zip_attributes':
        edit_archive(folder / 'input/export.sgx', lambda d: None, True)

def excel(path):
    book = load_workbook(path)
    values, styles = {}, {}
    for sheet in book:
        values[sheet.title] = [[cell.value for cell in row] for row in sheet]
        styles[sheet.title] = {
            'freeze': sheet.freeze_panes, 'filter': sheet.auto_filter.ref,
            'widths': {c: d.width for c, d in sheet.column_dimensions.items()},
            'validation': [(str(v.sqref), v.formula1, v.allow_blank) for v in sheet.data_validations.dataValidation],
            'cells': [[{'bold': c.font.bold, 'wrap': c.alignment.wrap_text,
                       'vertical': c.alignment.vertical, 'fill': str(c.fill)} for c in row] for row in sheet]
        }
    book.close()
    return values, styles

def semantic(path):
    if path.suffix == '.json':
        return json.loads(path.read_text('utf-8'))
    if path.suffix == '.xlsx':
        return excel(path)[0]
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            data = {}
            for n in z.namelist():
                content = z.read(n)
                data[n] = json.loads(content) if n.endswith('.json') else content.hex()
            return {'order': z.namelist(), 'content': data}
    return path.read_bytes().hex()

def check_archive(folder):
    dest = folder / 'output/export_modifie.sgx'
    if not dest.exists() or not zipfile.is_zipfile(dest):
        return None
    mods = json.loads((folder / 'output/modifications_validees.json').read_text('utf-8'))
    changed = {m['fichier_modele'] for m in mods}
    with zipfile.ZipFile(folder / 'input/export.sgx') as a, zipfile.ZipFile(dest) as b:
        assert a.namelist() == b.namelist()
        assert b.testzip() is None
        assert all(a.read(n) == b.read(n) for n in a.namelist() if n not in changed)
        attributes = []
        for n in a.namelist():
            x, y = a.getinfo(n), b.getinfo(n)
            diff = [k for k in ['compress_type', 'date_time', 'create_system', 'external_attr', 'extra', 'comment'] if getattr(x, k) != getattr(y, k)]
            if diff:
                attributes.append({'entry': n, 'changed_attributes': diff})
        return {'untouched_contents_preserved': True, 'attribute_changes': attributes,
                'archive_comment_preserved': a.comment == b.comment}

def execute(folder, command):
    before = {p.name: hashfile(p) for p in (folder / 'input').glob('*')}
    output_before = {p.name: hashfile(p) for p in (folder / 'output').glob('*.sgx')}
    run = subprocess.run(command, cwd=folder, capture_output=True,
                         env=dict(os.environ, PYTHONIOENCODING='utf-8'), timeout=60)
    assert before == {p.name: hashfile(p) for p in (folder / 'input').glob('*')}
    return {'code': run.returncode, 'stdout': run.stdout.decode('utf-8', errors='replace'),
            'stderr': run.stderr.decode('utf-8', errors='replace'),
            'source_intact': True, 'sgx_after': {p.name: hashfile(p) for p in (folder / 'output').glob('*.sgx')},
            'sgx_before': output_before, 'archive_check': check_archive(folder)}

results = []
for name in SCENARIOS + EXTRA:
    folder = out / name
    # Re-execution retains evidence in a fresh numbered directory.
    index = 1
    while folder.exists():
        folder = out / f'{name}-{index}'
        index += 1
    py, rs = folder / 'python', folder / 'rust'
    prepare(py, name)
    shutil.copytree(py, rs)
    left = execute(py, [sys.executable, str(stable)])
    right = execute(rs, [str(binary)])
    lfiles = {p.name: p for p in (py / 'output').glob('*')}
    rfiles = {p.name: p for p in (rs / 'output').glob('*')}
    differences = []
    presentation = []
    for filename in sorted(lfiles.keys() | rfiles.keys()):
        if filename not in lfiles or filename not in rfiles:
            differences.append({'file': filename, 'reason': 'presence'})
        elif semantic(lfiles[filename]) != semantic(rfiles[filename]):
            differences.append({'file': filename, 'reason': 'content'})
        if filename.endswith('.xlsx') and filename in lfiles and filename in rfiles:
            if excel(lfiles[filename])[1] != excel(rfiles[filename])[1]:
                presentation.append(filename)
    result = {'scenario': name, 'codes_equal': left['code'] == right['code'],
              'semantic_differences': differences, 'presentation_differences': presentation,
              'python': left, 'rust': right}
    results.append(result)
    print(name, 'codes', left['code'], right['code'], 'differences', differences, flush=True)

# SAPHIR: inventory then synthetic normalization decisions on disposable copies.
source = root / 'SAPHIR - Modélisation des processus cibles.sgx'
if source.exists():
    folder = out / ('saphir-' + str(len(list(out.glob('saphir-*')))))
    for app in ['python', 'rust']:
        f = folder / app
        for d in ['input', 'output', 'work']:
            (f / d).mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, f / 'input/export.sgx')
    commands = {'python': [sys.executable, str(stable)], 'rust': [str(binary)]}
    stages = []
    for stage in ['inventory', 'analysis', 'apply']:
        runs = {app: execute(folder / app, command) for app, command in commands.items()}
        assert all(r['code'] == 0 for r in runs.values())
        a, b = folder / 'python/output', folder / 'rust/output'
        differences = [p.name for p in a.iterdir() if not (b / p.name).exists() or semantic(p) != semantic(b / p.name)]
        stages.append({'stage': stage, 'differences': differences, 'runs': runs})
        if stage == 'inventory':
            synth = json.loads((a / 'synthese.json').read_text('utf-8'))
            mappings = [[n, re.sub(r'\s+', ' ', n).strip()] for n in synth if '\n' in n or '  ' in n]
            for app in commands:
                fixtures.workbook(folder / app / 'work/correspondance_swimlanes.xlsx', 'Correspondance', [['Nom actuel', 'Nouveau nom']] + mappings)
        if stage == 'analysis':
            proposals = json.loads((a / 'analyse_modifications.json').read_text('utf-8'))
            rows = [['Flux', 'Nom actuel', 'Nouveau nom', 'Occurrences', 'Validation', 'Fichier modèle']]
            rows += [[m['flux'], m['nom_actuel'], m['nouveau_nom'], m['occurrences'], 'OUI', m['fichier_modele']] for m in proposals]
            for app in commands:
                fixtures.workbook(folder / app / 'work/validation_modifications.xlsx', 'Analyse', rows)
    results.append({'scenario': 'saphir', 'mapping_names': len(mappings), 'proposals': len(proposals), 'stages': stages})
    print('SAPHIR', len(mappings), 'names', len(proposals), 'proposals', [s['differences'] for s in stages])
(root / 'rust-qualification-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print('Saved', root / 'rust-qualification-results.json')
