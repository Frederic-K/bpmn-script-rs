param([Parameter(Mandatory=$true)][string]$Python)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
$previousRustup = $env:RUSTUP_HOME
try {
    $env:RUSTUP_HOME = Join-Path $PSScriptRoot '.toolchains'
    & rustup toolchain install 1.88.0 --profile minimal --no-self-update
    if ($LASTEXITCODE -ne 0) { throw 'Installation Rust impossible' }
    & cargo +1.88.0 build --locked --manifest-path bpmn-script-rs-main/bpmn-script-rs-main/Cargo.toml
    if ($LASTEXITCODE -ne 0) { throw 'Compilation impossible' }
    & $Python -c 'import openpyxl; assert openpyxl.__version__ == "3.1.5", openpyxl.__version__'
    if ($LASTEXITCODE -ne 0) { throw 'Utiliser Python avec openpyxl 3.1.5' }
    & $Python qualify_rust.py
    if ($LASTEXITCODE -ne 0) { throw 'Qualification interrompue' }
    & $Python check_qualification.py
    if ($LASTEXITCODE -ne 0) { throw 'Écart nouveau détecté par les assertions' }
} finally {
    $env:RUSTUP_HOME = $previousRustup
    Pop-Location
}
